<div id="sidebar">
	<?php generated_dynamic_sidebar(); ?>
</div>