<?php global $smof_data; ?>
<?php if($smof_data['header_number'] || $smof_data['header_email']): ?>
<div class="header-info">
	
	<ul class="contact-details clearfix">
							<li class="template-phone">
					+84 650 652650				</li>
								<li class="template-mail">
										<a href="mailto:renovate@mail.com">
					johan@fine-Interior.com.vn				</a>
									</li>
								<li class="template-clock">
					Mon - Fri: 08.00 - 17.00				</li>
						</ul>
</div>
<?php endif; ?>
