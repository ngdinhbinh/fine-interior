<style type='text/css'>
.pyre_metabox { padding: 10px 10px 0px 10px; }
.pyre_metabox_field { margin-bottom: 15px; width: 100%; overflow: hidden; }
.pyre_metabox_field label { font-weight: bold; float: left; width: 15%; line-height: 26px; }
.pyre_metabox_field .field { float: left; width: 75%; }
.pyre_metabox_field input[type=text] { width: 100%; }
</style>